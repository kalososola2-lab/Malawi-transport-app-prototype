'use client'

import {
  createContext,
  useContext,
  useMemo,
  useState,
  type ReactNode,
} from 'react'
import { SEED_OPERATORS, SEED_ROUTES } from '@/lib/seed-data'
import type { Operator, Route, TransportRequest, UserRole } from '@/lib/types'

interface AppState {
  currentUser: Operator | null
  operators: Operator[]
  routes: Route[]
  requests: TransportRequest[]
  requestTransport: (request: Omit<TransportRequest, 'id' | 'status' | 'createdAt'>) => void
  acceptRequest: (id: string) => void
  updateDriverProfile: (plate: string, description: string) => void
  login: (email: string, password: string) => { ok: boolean; error?: string }
  register: (
    data: Omit<Operator, 'id'> & { role?: UserRole },
  ) => { ok: boolean; error?: string }
  logout: () => void
  addRoute: (route: Omit<Route, 'id' | 'operatorId' | 'operatorName'>) => void
  updateRoute: (route: Route) => void
  deleteRoute: (id: string) => void
}

const AppContext = createContext<AppState | null>(null)

let idCounter = 1000
const nextId = (prefix: string) => `${prefix}-${++idCounter}`

export function AuthProvider({ children }: { children: ReactNode }) {
  const [operators, setOperators] = useState<Operator[]>(SEED_OPERATORS)
  const [routes, setRoutes] = useState<Route[]>(SEED_ROUTES)
  const [requests, setRequests] = useState<TransportRequest[]>([])
  const [currentUser, setCurrentUser] = useState<Operator | null>(null)

  const value = useMemo<AppState>(() => {
    return {
      currentUser,
      operators,
      routes,
      requests,
      requestTransport(request) {
        setRequests((prev) => [
          { ...request, id: nextId('req'), status: 'pending', createdAt: new Date().toISOString() },
          ...prev,
        ])
      },
      acceptRequest(id) {
        if (!currentUser || currentUser.role !== 'driver') return
        setRequests((prev) => prev.map((request) => request.id === id ? { ...request, status: 'accepted', driverId: currentUser.id, driverName: currentUser.name } : request))
      },
      updateDriverProfile(plate, description) {
        if (!currentUser || currentUser.role !== 'driver') return
        setCurrentUser((prev) => prev ? { ...prev, vehiclePlate: plate, vehicleDescription: description } : prev)
      },
      login(email, password) {
        const match = operators.find(
          (o) => o.email.toLowerCase() === email.trim().toLowerCase(),
        )
        const demoCustomer: Operator = {
          id: 'customer-demo',
          role: 'customer',
          name: 'Demo Customer',
          email: 'customer@routehub.mw',
          password: 'demo1234',
          phone: '',
        }
        const demoDriver: Operator = {
          id: 'driver-demo',
          role: 'driver',
          name: 'Demo Driver',
          email: 'driver@routehub.mw',
          password: 'demo1234',
          phone: '+265 888 444 555',
        }
        const specialMatch = [demoCustomer, demoDriver].find(
          (u) => u.email === email.trim().toLowerCase(),
        )
        const account = match ?? specialMatch
        if (!account) return { ok: false, error: 'No account found for that email.' }
        if (account.password !== password)
          return { ok: false, error: 'Incorrect password.' }
        setCurrentUser(account)
        return { ok: true }
      },
      register(data) {
        const exists = operators.some(
          (o) => o.email.toLowerCase() === data.email.trim().toLowerCase(),
        )
        if (exists) return { ok: false, error: 'That email is already registered.' }
        const operator: Operator = { ...data, role: data.role ?? 'operator', id: nextId('op') }
        setOperators((prev) => [...prev, operator])
        setCurrentUser(operator)
        return { ok: true }
      },
      logout() {
        setCurrentUser(null)
      },
      addRoute(route) {
        if (!currentUser) return
        const newRoute: Route = {
          ...route,
          id: nextId('rt'),
          operatorId: currentUser.id,
          operatorName: currentUser.name,
        }
        setRoutes((prev) => [newRoute, ...prev])
      },
      updateRoute(route) {
        setRoutes((prev) => prev.map((r) => (r.id === route.id ? route : r)))
      },
      deleteRoute(id) {
        setRoutes((prev) => prev.filter((r) => r.id !== id))
      },
    }
  }, [currentUser, operators, routes])

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>
}

export function useApp(): AppState {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error('useApp must be used within AuthProvider')
  return ctx
}
