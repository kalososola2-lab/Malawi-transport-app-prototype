'use client'

import { useState } from 'react'
import { GripVertical, Plus, X } from 'lucide-react'
import { useApp } from '@/components/auth-provider'
import { MapView } from '@/components/map-view'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { formatKm, routeLengthKm } from '@/lib/geo'
import { fareFor, formatMwk } from '@/lib/pricing'
import { routeColor } from '@/lib/route-ui'
import { KNOWN_PLACES } from '@/lib/seed-data'
import type { QualityTier, Stop, VehicleType } from '@/lib/types'

export function RouteForm({ onDone }: { onDone: () => void }) {
  const { addRoute } = useApp()
  const [name, setName] = useState('')
  const [city, setCity] = useState('Lilongwe')
  const [vehicleType, setVehicleType] = useState<VehicleType>('minibus')
  const [vehiclePlate, setVehiclePlate] = useState('')
  const [quality, setQuality] = useState<QualityTier>('economy')
  const [frequencyMins, setFrequencyMins] = useState('10')
  const [operatingHours, setOperatingHours] = useState('05:00 – 20:00')
  const [fleetSize, setFleetSize] = useState('5')
  const [stops, setStops] = useState<Stop[]>([])
  const [placeToAdd, setPlaceToAdd] = useState('')
  const [error, setError] = useState('')

  function addStop() {
    if (placeToAdd === '') return
    const place = KNOWN_PLACES[Number(placeToAdd)]
    setStops((prev) => [...prev, { name: place.name, lat: place.lat, lng: place.lng }])
    setPlaceToAdd('')
  }

  function removeStop(index: number) {
    setStops((prev) => prev.filter((_, i) => i !== index))
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    if (!name.trim()) return setError('Give your route a name.')
    if (stops.length < 2) return setError('Add at least two stops.')

    addRoute({
      name: name.trim(),
      city,
      vehicleType,
      vehiclePlate: vehiclePlate.trim().toUpperCase(),
      quality,
      frequencyMins: Number(frequencyMins) || 10,
      operatingHours,
      fleetSize: Number(fleetSize) || 1,
      stops,
    })
    onDone()
  }

  const length = routeLengthKm(stops)
  const previewId = 'preview'

  return (
    <form
      onSubmit={handleSubmit}
      className="grid gap-6 rounded-xl border border-border bg-card p-6 lg:grid-cols-2"
    >
      <div className="flex flex-col gap-4">
        <div className="flex flex-col gap-1.5">
          <Label>Route name</Label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Old Town — City Centre"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5">
            <Label>City</Label>
            <Input value={city} onChange={(e) => setCity(e.target.value)} />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Vehicle</Label>
            <Select
              value={vehicleType}
              onValueChange={(v) => setVehicleType(v as VehicleType)}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="minibus">Minibus</SelectItem>
                <SelectItem value="taxi">Taxi</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5">
            <Label>Number plate</Label>
            <Input
              value={vehiclePlate}
              onChange={(e) => setVehiclePlate(e.target.value)}
              placeholder="e.g. NA 1234"
              maxLength={12}
              autoCapitalize="characters"
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Quality</Label>
            <Select
              value={quality}
              onValueChange={(v) => setQuality(v as QualityTier)}
            >
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="economy">Economy</SelectItem>
                <SelectItem value="standard">Standard</SelectItem>
                <SelectItem value="premium">Premium</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Departs every (min)</Label>
            <Input
              type="number"
              min={1}
              value={frequencyMins}
              onChange={(e) => setFrequencyMins(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5">
            <Label>Operating hours</Label>
            <Input
              value={operatingHours}
              onChange={(e) => setOperatingHours(e.target.value)}
            />
          </div>
          <div className="flex flex-col gap-1.5">
            <Label>Fleet size</Label>
            <Input
              type="number"
              min={1}
              value={fleetSize}
              onChange={(e) => setFleetSize(e.target.value)}
            />
          </div>
        </div>

        <div className="flex flex-col gap-1.5">
          <Label>Add stops in travel order</Label>
          <div className="flex gap-2">
            <Select value={placeToAdd} onValueChange={(next) => next !== null && setPlaceToAdd(next)}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Select a place" />
              </SelectTrigger>
              <SelectContent>
                {KNOWN_PLACES.map((p, i) => (
                  <SelectItem key={p.name} value={String(i)}>
                    {p.name} · {p.city}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Button type="button" variant="secondary" onClick={addStop}>
              <Plus className="size-4" />
            </Button>
          </div>
        </div>

        {stops.length > 0 && (
          <ul className="flex flex-col gap-2">
            {stops.map((stop, i) => (
              <li
                key={`${stop.name}-${i}`}
                className="flex items-center justify-between gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm"
              >
                <span className="flex items-center gap-2">
                  <GripVertical className="size-4 text-muted-foreground" />
                  <span className="text-xs text-muted-foreground">{i + 1}.</span>
                  {stop.name}
                </span>
                <button
                  type="button"
                  onClick={() => removeStop(i)}
                  aria-label={`Remove ${stop.name}`}
                  className="text-muted-foreground hover:text-destructive"
                >
                  <X className="size-4" />
                </button>
              </li>
            ))}
          </ul>
        )}

        {error && <p className="text-sm text-destructive">{error}</p>}

        <div className="flex items-center gap-2">
          <Button type="submit">Publish route</Button>
          <Button type="button" variant="ghost" onClick={onDone}>
            Cancel
          </Button>
        </div>
      </div>

      <div className="flex flex-col gap-3">
        <div className="overflow-hidden rounded-lg border border-border">
          <MapView
            routes={
              stops.length > 0
                ? [
                    {
                      id: previewId,
                      name: name || 'New route',
                      color: routeColor(previewId),
                      stops,
                    },
                  ]
                : []
            }
            height={300}
          />
        </div>
        <div className="grid grid-cols-2 gap-3">
          <div className="rounded-lg border border-border bg-background p-3">
            <p className="text-xs text-muted-foreground">Route length</p>
            <p className="mt-1 font-semibold">{formatKm(length)}</p>
          </div>
          <div className="rounded-lg border border-border bg-background p-3">
            <p className="text-xs text-muted-foreground">Full-route fare</p>
            <p className="mt-1 font-semibold text-primary">
              {formatMwk(fareFor(quality, length))}
            </p>
          </div>
        </div>
        <p className="text-xs text-muted-foreground">
          Fares update live from the total distance and the quality tier you
          select.
        </p>
      </div>
    </form>
  )
}
