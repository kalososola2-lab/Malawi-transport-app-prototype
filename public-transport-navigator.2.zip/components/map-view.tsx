'use client'

import dynamic from 'next/dynamic'
import type { RouteMapProps } from './route-map'

export type { MapPin } from './route-map'

const RouteMap = dynamic(() => import('./route-map'), {
  ssr: false,
  loading: () => (
    <div
      className="flex w-full items-center justify-center rounded-lg border border-border bg-card text-sm text-muted-foreground"
      style={{ height: 420 }}
    >
      Loading map…
    </div>
  ),
})

export function MapView(props: RouteMapProps) {
  return <RouteMap {...props} />
}
