'use client'

import 'leaflet/dist/leaflet.css'
import { useEffect } from 'react'
import {
  CircleMarker,
  MapContainer,
  Polyline,
  TileLayer,
  Tooltip,
  useMap,
  useMapEvents,
} from 'react-leaflet'
import { MALAWI_CENTER } from '@/lib/seed-data'
import type { Stop } from '@/lib/types'

export interface MapRoute {
  id: string
  name: string
  color: string
  stops: Stop[]
}

export interface MapPin {
  lat: number
  lng: number
  label: string
  kind: 'origin' | 'destination' | 'match' | 'vehicle'
}

export interface RouteMapProps {
  routes?: MapRoute[]
  pins?: MapPin[]
  height?: number | string
  onMapClick?: (point: { lat: number; lng: number }) => void
}

const PIN_COLORS: Record<MapPin['kind'], string> = {
  origin: '#38bdf8',
  destination: '#22c55e',
  match: '#f59e0b',
  vehicle: '#2563eb',
}

function MapClickHandler({ onMapClick }: { onMapClick?: RouteMapProps['onMapClick'] }) {
  useMapEvents({
    click: (event) => onMapClick?.({ lat: event.latlng.lat, lng: event.latlng.lng }),
  })
  return null
}

function FitBounds({ routes, pins }: { routes: MapRoute[]; pins: MapPin[] }) {
  const map = useMap()

  useEffect(() => {
    const coords: [number, number][] = []
    routes.forEach((r) => r.stops.forEach((s) => coords.push([s.lat, s.lng])))
    pins.forEach((p) => coords.push([p.lat, p.lng]))

    if (coords.length === 0) return
    if (coords.length === 1) {
      map.setView(coords[0], 13)
      return
    }
    map.fitBounds(coords, { padding: [40, 40] })
  }, [map, routes, pins])

  return null
}

export default function RouteMap({
  routes = [],
  pins = [],
  height = 420,
  onMapClick,
}: RouteMapProps) {
  return (
    <MapContainer
      center={[MALAWI_CENTER.lat, MALAWI_CENTER.lng]}
      zoom={7}
      scrollWheelZoom
      style={{ height, width: '100%' }}
      className="z-0"
    >
      <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      <MapClickHandler onMapClick={onMapClick} />

      {routes.map((route) => (
        <div key={route.id}>
          <Polyline
            positions={route.stops.map((s) => [s.lat, s.lng])}
            pathOptions={{ color: route.color, weight: 4, opacity: 0.9 }}
          />
          {route.stops.map((stop, i) => (
            <CircleMarker
              key={`${route.id}-${i}`}
              center={[stop.lat, stop.lng]}
              radius={5}
              pathOptions={{
                color: route.color,
                fillColor: '#0b1220',
                fillOpacity: 1,
                weight: 2,
              }}
            >
              <Tooltip>{stop.name}</Tooltip>
            </CircleMarker>
          ))}
        </div>
      ))}

      {pins.map((pin, i) => (
        <CircleMarker
          key={`pin-${i}`}
          center={[pin.lat, pin.lng]}
          radius={9}
          pathOptions={{
            color: '#ffffff',
            fillColor: PIN_COLORS[pin.kind],
            fillOpacity: 1,
            weight: 3,
          }}
        >
          <Tooltip permanent direction="top" offset={[0, -8]}>
            {pin.label}
          </Tooltip>
        </CircleMarker>
      ))}

      <FitBounds routes={routes} pins={pins} />
    </MapContainer>
  )
}
