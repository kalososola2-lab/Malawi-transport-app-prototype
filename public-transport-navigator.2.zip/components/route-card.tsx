import Link from 'next/link'
import { Bus, Car, Clock, MapPin } from 'lucide-react'
import { Badge } from '@/components/ui/badge'
import { formatKm, routeLengthKm } from '@/lib/geo'
import { fareFor, formatMwk } from '@/lib/pricing'
import { QUALITY_BADGE, routeColor } from '@/lib/route-ui'
import { cn } from '@/lib/utils'
import type { Route } from '@/lib/types'

export function RouteCard({ route }: { route: Route }) {
  const length = routeLengthKm(route.stops)
  const endToEnd = fareFor(route.quality, length)
  const quality = QUALITY_BADGE[route.quality]
  const origin = route.stops[0]?.name
  const destination = route.stops[route.stops.length - 1]?.name

  return (
    <Link
      href={`/routes/${route.id}`}
      className="group block rounded-xl border border-border bg-card p-5 transition-colors hover:border-primary/60"
    >
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-2">
          <span
            className="size-2.5 shrink-0 rounded-full"
            style={{ backgroundColor: routeColor(route.id) }}
            aria-hidden
          />
          <h3 className="text-balance font-semibold leading-tight text-card-foreground">
            {route.name}
          </h3>
        </div>
        <Badge variant="outline" className={cn('shrink-0', quality.className)}>
          {quality.label}
        </Badge>
      </div>

      <div className="mt-3 flex items-center gap-1.5 text-sm text-muted-foreground">
        <MapPin className="size-3.5 text-primary" />
        <span className="truncate">
          {origin} → {destination}
        </span>
      </div>

      <div className="mt-4 flex flex-wrap items-center gap-x-4 gap-y-2 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1">
          {route.vehicleType === 'taxi' ? (
            <Car className="size-3.5" />
          ) : (
            <Bus className="size-3.5" />
          )}
          {route.vehicleType === 'taxi' ? 'Taxi' : 'Minibus'}
        </span>
        <span className="inline-flex items-center gap-1">
          <Clock className="size-3.5" />
          every {route.frequencyMins} min
        </span>
        <span>{formatKm(length)}</span>
        <span className="text-muted-foreground/70">{route.city}</span>
        {route.vehiclePlate && (
          <span className="font-mono text-[11px] text-foreground/80" aria-label={`Number plate ${route.vehiclePlate}`}>
            {route.vehiclePlate}
          </span>
        )}
      </div>

      <div className="mt-4 flex items-center justify-between border-t border-border pt-4">
        <span className="text-xs text-muted-foreground">Full-route fare</span>
        <span className="font-semibold text-primary">{formatMwk(endToEnd)}</span>
      </div>
    </Link>
  )
}
