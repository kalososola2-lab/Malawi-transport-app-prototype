'use client'

import Link from 'next/link'
import { usePathname, useRouter } from 'next/navigation'
import { Bus, LogOut } from 'lucide-react'
import { useApp } from '@/components/auth-provider'
import { Button } from '@/components/ui/button'
import { cn } from '@/lib/utils'

const NAV = [
  { href: '/routes', label: 'Routes' },
  { href: '/find', label: 'Find Transport' },
]

export function SiteHeader() {
  const pathname = usePathname()
  const router = useRouter()
  const { currentUser, logout } = useApp()

  return (
    <header className="sticky top-0 z-50 border-b border-border bg-background/80 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between px-4">
        <Link href="/" className="flex items-center gap-2">
          <span className="flex size-9 items-center justify-center rounded-lg bg-primary text-primary-foreground">
            <Bus className="size-5" />
          </span>
          <span className="text-lg font-semibold tracking-tight">
            RouteHub <span className="text-primary">MW</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          {[...NAV, ...(currentUser?.role === 'operator' ? [{ href: '/dashboard', label: 'Operator Panel' }] : []), ...(currentUser?.role === 'driver' ? [{ href: '/driver', label: 'Driver Panel' }] : [])].map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'rounded-md px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:text-foreground',
                pathname.startsWith(item.href) && 'text-foreground',
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          {currentUser ? (
            <>
              <span className="hidden text-sm text-muted-foreground sm:inline">
                {currentUser.name}
              </span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => {
                  logout()
                  router.push('/')
                }}
              >
                <LogOut className="size-4" />
                <span className="sr-only sm:not-sr-only sm:ml-1">Log out</span>
              </Button>
            </>
          ) : (
            <Button
              size="sm"
              nativeButton={false}
              render={<Link href="/login" />}
            >
              Operator Login
            </Button>
          )}
        </div>
      </div>
    </header>
  )
}
