import type { QualityTier } from './types'

const PALETTE = [
  '#38bdf8',
  '#22c55e',
  '#f59e0b',
  '#a78bfa',
  '#f472b6',
  '#2dd4bf',
  '#fb7185',
]

/** Deterministic color for a route id so the map and lists stay in sync. */
export function routeColor(id: string): string {
  let hash = 0
  for (let i = 0; i < id.length; i++) {
    hash = (hash * 31 + id.charCodeAt(i)) >>> 0
  }
  return PALETTE[hash % PALETTE.length]
}

export const QUALITY_BADGE: Record<
  QualityTier,
  { label: string; className: string }
> = {
  economy: {
    label: 'Economy',
    className: 'bg-sky-500/15 text-sky-300 border-sky-500/30',
  },
  standard: {
    label: 'Standard',
    className: 'bg-blue-500/15 text-blue-300 border-blue-500/30',
  },
  premium: {
    label: 'Premium',
    className: 'bg-amber-500/15 text-amber-300 border-amber-500/30',
  },
}
