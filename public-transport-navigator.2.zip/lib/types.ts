export type VehicleType = 'minibus' | 'taxi'
export type QualityTier = 'economy' | 'standard' | 'premium'
export type UserRole = 'customer' | 'driver' | 'operator'

export interface LatLng {
  lat: number
  lng: number
}

export interface Stop {
  name: string
  lat: number
  lng: number
}

export interface Operator {
  id: string
  name: string
  email: string
  password: string
  phone: string
  role?: UserRole
  vehiclePlate?: string
  vehicleDescription?: string
}

export type RequestStatus = 'pending' | 'accepted' | 'completed'

export interface TransportRequest {
  id: string
  customerName: string
  customerPhone: string
  pickup: string
  destination: string
  distanceKm: number
  fare: number
  vehicleType: VehicleType
  status: RequestStatus
  driverName?: string
  driverId?: string
  createdAt: string
}

export interface Route {
  id: string
  operatorId: string
  operatorName: string
  name: string
  city: string
  vehicleType: VehicleType
  /** Vehicle registration / number plate shown to customers. */
  vehiclePlate?: string
  quality: QualityTier
  /** Ordered list of stops that define the route path (origin -> destination). */
  stops: Stop[]
  /** How often a vehicle departs, in minutes. */
  frequencyMins: number
  operatingHours: string
  fleetSize: number
}

export interface QualityProfile {
  label: string
  /** One-time base fare in MWK. */
  baseFare: number
  /** Fare per kilometre in MWK. */
  perKm: number
  description: string
}
