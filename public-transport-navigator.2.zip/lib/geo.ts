import type { LatLng, Stop } from './types'

const EARTH_RADIUS_KM = 6371

function toRad(value: number): number {
  return (value * Math.PI) / 180
}

/** Great-circle distance between two points in kilometres. */
export function haversineKm(a: LatLng, b: LatLng): number {
  const dLat = toRad(b.lat - a.lat)
  const dLng = toRad(b.lng - a.lng)
  const lat1 = toRad(a.lat)
  const lat2 = toRad(b.lat)

  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.sqrt(h))
}

/** Total travelled distance along an ordered list of stops (km). */
export function routeLengthKm(stops: Stop[]): number {
  let total = 0
  for (let i = 1; i < stops.length; i++) {
    total += haversineKm(stops[i - 1], stops[i])
  }
  return total
}

/** Travelled distance between two stop indices along the route (km). */
export function segmentLengthKm(
  stops: Stop[],
  fromIndex: number,
  toIndex: number,
): number {
  const start = Math.min(fromIndex, toIndex)
  const end = Math.max(fromIndex, toIndex)
  let total = 0
  for (let i = start + 1; i <= end; i++) {
    total += haversineKm(stops[i - 1], stops[i])
  }
  return total
}

/** Index of the stop closest to a given point. */
export function nearestStopIndex(stops: Stop[], point: LatLng): number {
  let bestIndex = 0
  let bestDist = Number.POSITIVE_INFINITY
  stops.forEach((stop, i) => {
    const d = haversineKm(stop, point)
    if (d < bestDist) {
      bestDist = d
      bestIndex = i
    }
  })
  return bestIndex
}

export function formatKm(km: number): string {
  if (km < 1) return `${Math.round(km * 1000)} m`
  return `${km.toFixed(1)} km`
}
