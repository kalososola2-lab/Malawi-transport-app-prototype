import type { QualityProfile, QualityTier } from './types'

/**
 * Per-km rate varies by transport quality (plus a quality-specific base fare).
 * Fares are in Malawian Kwacha (MWK).
 */
export const QUALITY_PROFILES: Record<QualityTier, QualityProfile> = {
  economy: {
    label: 'Economy',
    baseFare: 0,
    perKm: 500,
    description: 'Standard minibus, shared seating, most affordable.',
  },
  standard: {
    label: 'Standard',
    baseFare: 0,
    perKm: 1000,
    description: 'Well-maintained vehicle, fewer stops, reserved seats.',
  },
  premium: {
    label: 'Premium',
    baseFare: 0,
    perKm: 3000,
    description: 'Air-conditioned, direct service, extra comfort and space.',
  },
}

export function fareFor(quality: QualityTier, distanceKm: number): number {
  const profile = QUALITY_PROFILES[quality]
  const raw = profile.baseFare + profile.perKm * distanceKm
  // Round to nearest 50 MWK, the smallest note commonly used.
  return Math.max(profile.baseFare, Math.round(raw / 50) * 50)
}

const kwacha = new Intl.NumberFormat('en-MW', {
  style: 'currency',
  currency: 'MWK',
  maximumFractionDigits: 0,
})

export function formatMwk(amount: number): string {
  return kwacha.format(amount)
}
