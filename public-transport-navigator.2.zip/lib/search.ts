import {
  haversineKm,
  nearestStopIndex,
  segmentLengthKm,
} from './geo'
import { fareFor } from './pricing'
import type { LatLng, Route, Stop } from './types'

export interface TripOption {
  route: Route
  boardingStop: Stop
  alightStop: Stop
  boardingWalkKm: number
  alightWalkKm: number
  travelKm: number
  fare: number
  /** Whether the customer travels in the listed stop order or the reverse. */
  reversed: boolean
}

/**
 * Find viable trips that get a customer from `origin` toward `destination`.
 * A route qualifies when it has a stop within `maxWalkKm` of both points.
 * Results are sorted by how close the boarding stop is (nearest transport first).
 */
export function findTrips(
  routes: Route[],
  origin: LatLng,
  destination: LatLng,
  maxWalkKm = 3,
): TripOption[] {
  const options: TripOption[] = []

  for (const route of routes) {
    if (route.stops.length < 2) continue

    const boardingIndex = nearestStopIndex(route.stops, origin)
    const alightIndex = nearestStopIndex(route.stops, destination)
    if (boardingIndex === alightIndex) continue

    const boardingStop = route.stops[boardingIndex]
    const alightStop = route.stops[alightIndex]
    const boardingWalkKm = haversineKm(origin, boardingStop)
    const alightWalkKm = haversineKm(destination, alightStop)

    if (boardingWalkKm > maxWalkKm || alightWalkKm > maxWalkKm) continue

    const travelKm = segmentLengthKm(route.stops, boardingIndex, alightIndex)
    const fare = fareFor(route.quality, travelKm)

    options.push({
      route,
      boardingStop,
      alightStop,
      boardingWalkKm,
      alightWalkKm,
      travelKm,
      fare,
      reversed: alightIndex < boardingIndex,
    })
  }

  return options.sort((a, b) => a.boardingWalkKm - b.boardingWalkKm)
}
