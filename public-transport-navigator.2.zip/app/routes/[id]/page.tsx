'use client'

import Link from 'next/link'
import { useParams } from 'next/navigation'
import { ArrowLeft, Bus, Car, Clock, Users } from 'lucide-react'
import { useApp } from '@/components/auth-provider'
import { MapView } from '@/components/map-view'
import { SiteHeader } from '@/components/site-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatKm, segmentLengthKm } from '@/lib/geo'
import { fareFor, formatMwk, QUALITY_PROFILES } from '@/lib/pricing'
import { QUALITY_BADGE, routeColor } from '@/lib/route-ui'
import { cn } from '@/lib/utils'

export default function RouteDetailPage() {
  const params = useParams<{ id: string }>()
  const { routes } = useApp()
  const route = routes.find((r) => r.id === params.id)

  if (!route) {
    return (
      <div className="min-h-screen">
        <SiteHeader />
        <main className="mx-auto max-w-3xl px-4 py-20 text-center">
          <h1 className="text-xl font-semibold">Route not found</h1>
          <p className="mt-2 text-sm text-muted-foreground">
            This route may have been removed.
          </p>
          <Button
            className="mt-6"
            nativeButton={false}
            render={<Link href="/routes" />}
          >
            Back to routes
          </Button>
        </main>
      </div>
    )
  }

  const quality = QUALITY_BADGE[route.quality]
  const profile = QUALITY_PROFILES[route.quality]

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-8">
        <Link
          href="/routes"
          className="inline-flex items-center gap-1 text-sm text-muted-foreground transition-colors hover:text-foreground"
        >
          <ArrowLeft className="size-4" />
          All routes
        </Link>

        <div className="mt-4 flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-balance text-2xl font-semibold md:text-3xl">
              {route.name}
            </h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Operated by {route.operatorName} · {route.city}
            </p>
          </div>
          <Badge variant="outline" className={cn('text-sm', quality.className)}>
            {quality.label}
          </Badge>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <div className="overflow-hidden rounded-xl border border-border">
              <MapView
                routes={[
                  {
                    id: route.id,
                    name: route.name,
                    color: routeColor(route.id),
                    stops: route.stops,
                  },
                ]}
                height={440}
              />
            </div>

            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
  <Stat
    icon={route.vehicleType === 'taxi' ? Car : Bus}
    label="Vehicle"
    value={route.vehicleType === 'taxi' ? 'Taxi' : 'Minibus'}
  />
  <Stat icon={Car} label="Number plate" value={route.vehiclePlate || 'Not provided'} />
              <Stat
                icon={Clock}
                label="Frequency"
                value={`every ${route.frequencyMins}m`}
              />
              <Stat icon={Users} label="Fleet" value={`${route.fleetSize} cars`} />
              <Stat
                icon={Clock}
                label="Hours"
                value={route.operatingHours}
              />
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="rounded-xl border border-border bg-card p-5">
              <h2 className="font-semibold">Fares from {route.stops[0]?.name}</h2>
              <p className="mt-1 text-xs text-muted-foreground">
                {formatMwk(profile.perKm)}/km + {formatMwk(profile.baseFare)} base
                fare
              </p>
              <ul className="mt-4 flex flex-col gap-2">
                {route.stops.slice(1).map((stop, i) => {
                  const dist = segmentLengthKm(route.stops, 0, i + 1)
                  return (
                    <li
                      key={stop.name}
                      className="flex items-center justify-between gap-2 border-b border-border pb-2 text-sm last:border-0"
                    >
                      <span className="flex items-center gap-2">
                        <span
                          className="size-2 rounded-full"
                          style={{ backgroundColor: routeColor(route.id) }}
                        />
                        <span>{stop.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {formatKm(dist)}
                        </span>
                      </span>
                      <span className="font-medium text-primary">
                        {formatMwk(fareFor(route.quality, dist))}
                      </span>
                    </li>
                  )
                })}
              </ul>
            </div>

            <Button
              variant="outline"
              className="mt-4 w-full"
              nativeButton={false}
              render={<Link href="/find" />}
            >
              Find this transport near me
            </Button>
          </div>
        </div>
      </main>
    </div>
  )
}

function Stat({
  icon: Icon,
  label,
  value,
}: {
  icon: React.ComponentType<{ className?: string }>
  label: string
  value: string
}) {
  return (
    <div className="rounded-lg border border-border bg-card p-3">
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground">
        <Icon className="size-3.5" />
        {label}
      </div>
      <p className="mt-1 text-sm font-medium">{value}</p>
    </div>
  )
}
