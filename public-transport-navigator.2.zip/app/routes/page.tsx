'use client'

import { useMemo, useState } from 'react'
import { useApp } from '@/components/auth-provider'
import { MapView } from '@/components/map-view'
import { RouteCard } from '@/components/route-card'
import { SiteHeader } from '@/components/site-header'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { routeColor } from '@/lib/route-ui'

export default function RoutesPage() {
  const { routes } = useApp()
  const [city, setCity] = useState('all')
  const [vehicle, setVehicle] = useState('all')
  const [quality, setQuality] = useState('all')

  const cities = useMemo(
    () => ['all', ...Array.from(new Set(routes.map((r) => r.city)))],
    [routes],
  )

  const filtered = useMemo(
    () =>
      routes.filter(
        (r) =>
          (city === 'all' || r.city === city) &&
          (vehicle === 'all' || r.vehicleType === vehicle) &&
          (quality === 'all' || r.quality === quality),
      ),
    [routes, city, vehicle, quality],
  )

  const mapRoutes = filtered.map((r) => ({
    id: r.id,
    name: r.name,
    color: routeColor(r.id),
    stops: r.stops,
  }))

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold">Transport routes</h1>
          <p className="text-sm text-muted-foreground">
            Browse minibus and taxi routes published by operators across Malawi.
          </p>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-5">
          <div className="lg:col-span-3">
            <div className="overflow-hidden rounded-xl border border-border">
              <MapView routes={mapRoutes} height={460} />
            </div>
          </div>

          <div className="lg:col-span-2">
            <div className="flex flex-wrap gap-2">
              <FilterSelect
                value={city}
                onChange={setCity}
                placeholder="City"
                options={cities.map((c) => ({
                  value: c,
                  label: c === 'all' ? 'All cities' : c,
                }))}
              />
              <FilterSelect
                value={vehicle}
                onChange={setVehicle}
                placeholder="Vehicle"
                options={[
                  { value: 'all', label: 'All vehicles' },
                  { value: 'minibus', label: 'Minibus' },
                  { value: 'taxi', label: 'Taxi' },
                ]}
              />
              <FilterSelect
                value={quality}
                onChange={setQuality}
                placeholder="Quality"
                options={[
                  { value: 'all', label: 'All quality' },
                  { value: 'economy', label: 'Economy' },
                  { value: 'standard', label: 'Standard' },
                  { value: 'premium', label: 'Premium' },
                ]}
              />
            </div>

            <p className="mt-4 text-xs text-muted-foreground">
              {filtered.length} route{filtered.length === 1 ? '' : 's'}
            </p>

            <div className="mt-3 flex max-h-[520px] flex-col gap-3 overflow-y-auto pr-1">
              {filtered.map((route) => (
                <RouteCard key={route.id} route={route} />
              ))}
              {filtered.length === 0 && (
                <p className="rounded-lg border border-border bg-card p-6 text-center text-sm text-muted-foreground">
                  No routes match these filters.
                </p>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

function FilterSelect({
  value,
  onChange,
  placeholder,
  options,
}: {
  value: string
  onChange: (v: string) => void
  placeholder: string
  options: { value: string; label: string }[]
}) {
  return (
    <Select value={value} onValueChange={(next) => next !== null && onChange(next)}>
      <SelectTrigger className="w-[140px]" size="sm">
        <SelectValue placeholder={placeholder} />
      </SelectTrigger>
      <SelectContent>
        {options.map((o) => (
          <SelectItem key={o.value} value={o.value}>
            {o.label}
          </SelectItem>
        ))}
      </SelectContent>
    </Select>
  )
}
