import Link from 'next/link'
import {
  ArrowRight,
  Coins,
  Map as MapIcon,
  Navigation,
  ShieldCheck,
} from 'lucide-react'
import { SiteHeader } from '@/components/site-header'
import { Button } from '@/components/ui/button'
import { QUALITY_PROFILES } from '@/lib/pricing'
import { formatMwk } from '@/lib/pricing'

const FEATURES = [
  {
    icon: MapIcon,
    title: 'Every route on one map',
    body: 'Operators publish their minibus and taxi routes. Customers see the full network across Malawi in one place.',
  },
  {
    icon: Navigation,
    title: 'Find the nearest ride',
    body: 'Pick where you are and where you are going — we surface the closest transport heading your way.',
  },
  {
    icon: Coins,
    title: 'Fair, transparent fares',
    body: 'Prices are calculated from real distance and the quality of the vehicle, so you know the cost before you board.',
  },
]

export default function HomePage() {
  return (
    <div className="min-h-screen">
      <SiteHeader />

      <section className="relative isolate min-h-[620px] overflow-hidden border-b border-primary/15">
        <img
          src="/hero-minibus.png"
          alt="A minibus travelling through a Malawian city at dusk"
          className="absolute inset-0 size-full object-cover object-center opacity-45 mix-blend-screen"
        />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_72%_35%,oklch(0.56_0.18_220_/_20%),transparent_25rem)]" />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/80 to-background/35" />
        <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-background to-transparent" />
        <div className="relative mx-auto flex min-h-[620px] max-w-6xl items-center px-4 py-24 md:py-32">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-3 py-1 text-xs font-medium text-muted-foreground">
              <span className="size-1.5 rounded-full bg-primary" />
              Public transport for Malawi
            </span>
            <h1 className="mt-5 text-balance text-4xl font-bold leading-tight tracking-tight md:text-6xl">
              Know your route. Know your fare.{' '}
              <span className="text-primary">Before you board.</span>
            </h1>
            <p className="mt-5 max-w-xl text-pretty text-lg leading-relaxed text-muted-foreground">
              RouteHub connects minibus and taxi operators with riders across
              Lilongwe, Blantyre and beyond. Find the nearest transport to your
              destination and see a fair, distance-based price up front.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button
                size="lg"
                nativeButton={false}
                render={<Link href="/find" />}
              >
                Find transport
                <ArrowRight className="size-4" />
              </Button>
              <Button
                size="lg"
                variant="outline"
                nativeButton={false}
                render={<Link href="/routes" />}
              >
                Browse routes
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 py-16">
        <div className="grid gap-5 md:grid-cols-3">
          {FEATURES.map((f) => (
            <div
              key={f.title}
              className="glass-panel rounded-2xl p-6 transition-transform duration-300 hover:-translate-y-1"
            >
              <span className="flex size-11 items-center justify-center rounded-lg bg-primary/15 text-primary">
                <f.icon className="size-5" />
              </span>
              <h3 className="mt-4 font-semibold">{f.title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {f.body}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-16">
        <div className="glass-panel route-glow rounded-2xl p-8">
          <div className="flex flex-col gap-2 md:flex-row md:items-end md:justify-between">
            <div>
              <h2 className="text-2xl font-semibold">Pricing by quality</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Each ride is priced from the distance travelled and the class of
                the vehicle. Rates are in Malawian Kwacha.
              </p>
            </div>
          </div>
          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {Object.entries(QUALITY_PROFILES).map(([key, p]) => (
              <div
                key={key}
                className="rounded-xl border border-border bg-background p-5"
              >
                <h3 className="font-semibold text-card-foreground">{p.label}</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  {p.description}
                </p>
                <div className="mt-4 flex items-baseline gap-1">
                  <span className="text-2xl font-bold text-primary">
                    {formatMwk(p.perKm)}
                  </span>
                  <span className="text-sm text-muted-foreground">/ km</span>
                </div>
                <p className="mt-1 text-xs text-muted-foreground">
                  + {formatMwk(p.baseFare)} base fare
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pb-24">
        <div className="flex flex-col items-start gap-4 rounded-2xl border border-primary/30 bg-primary/10 p-8 md:flex-row md:items-center md:justify-between">
          <div className="flex items-start gap-4">
            <span className="flex size-11 items-center justify-center rounded-lg bg-primary text-primary-foreground">
              <ShieldCheck className="size-5" />
            </span>
            <div>
              <h2 className="text-xl font-semibold">Run a minibus or taxi service?</h2>
              <p className="mt-1 max-w-lg text-sm text-muted-foreground">
                Publish your routes, stops and schedules so thousands of riders
                can find you. Managing your routes is free.
              </p>
            </div>
          </div>
          <Button
            size="lg"
            nativeButton={false}
            render={<Link href="/login" />}
          >
            List your routes
          </Button>
        </div>
      </section>

      <footer className="border-t border-border">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-2 px-4 py-8 text-sm text-muted-foreground sm:flex-row">
          <span>RouteHub Malawi — demo platform</span>
          <span>Fares in MWK. Data is illustrative.</span>
        </div>
      </footer>
    </div>
  )
}
