'use client'

import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Bus } from 'lucide-react'
import { useApp } from '@/components/auth-provider'
import { SiteHeader } from '@/components/site-header'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { cn } from '@/lib/utils'

export default function LoginPage() {
  const router = useRouter()
  const { currentUser, login, register } = useApp()
  const [mode, setMode] = useState<'login' | 'register'>('login')
  const [error, setError] = useState('')

  // Prefilled demo credentials for convenience.
  const [email, setEmail] = useState('demo@routehub.mw')
  const [password, setPassword] = useState('demo1234')
  const [name, setName] = useState('')
  const [phone, setPhone] = useState('')

  useEffect(() => {
    if (currentUser) {
      router.push(currentUser.role === 'operator' ? '/dashboard' : currentUser.role === 'driver' ? '/driver' : '/find')
    }
  }, [currentUser, router])

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setError('')
    const result =
      mode === 'login'
        ? login(email, password)
        : register({ name, email, password, phone, role: 'operator' })
    if (!result.ok) setError(result.error ?? 'Something went wrong.')
    else router.push(result.ok && mode === 'register' ? '/dashboard' : email.toLowerCase().includes('driver') ? '/driver' : email.toLowerCase().includes('customer') ? '/find' : '/dashboard')
  }

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto flex max-w-md flex-col px-4 py-12">
        <div className="flex flex-col items-center text-center">
          <span className="flex size-12 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Bus className="size-6" />
          </span>
          <h1 className="mt-4 text-2xl font-semibold">Operator portal</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Publish and manage your minibus or taxi routes.
          </p>
        </div>

        <div className="mt-8 rounded-xl border border-border bg-card p-6">
          <div className="mb-6 grid grid-cols-2 gap-1 rounded-lg bg-background p-1">
            {(['login', 'register'] as const).map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => {
                  setMode(m)
                  setError('')
                }}
                className={cn(
                  'rounded-md px-3 py-1.5 text-sm font-medium transition-colors',
                  mode === m
                    ? 'bg-primary text-primary-foreground'
                    : 'text-muted-foreground hover:text-foreground',
                )}
              >
                {m === 'login' ? 'Log in' : 'Register'}
              </button>
            ))}
          </div>

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {mode === 'register' && (
              <>
                <Field
                  label="Business name"
                  value={name}
                  onChange={setName}
                  placeholder="Capital City Coaches"
                  required
                />
                <Field
                  label="Phone"
                  value={phone}
                  onChange={setPhone}
                  placeholder="+265 ..."
                  required
                />
              </>
            )}
            <Field
              label="Email"
              type="email"
              value={email}
              onChange={setEmail}
              placeholder="you@company.mw"
              required
            />
            <Field
              label="Password"
              type="password"
              value={password}
              onChange={setPassword}
              placeholder="••••••••"
              required
            />

            {error && <p className="text-sm text-destructive">{error}</p>}

            <Button type="submit" className="mt-2 w-full">
              {mode === 'login' ? 'Log in' : 'Create account'}
            </Button>
          </form>

          {mode === 'login' && (
            <p className="mt-4 rounded-lg bg-background p-3 text-center text-xs text-muted-foreground">
              Demo account is prefilled — just click{' '}
              <span className="text-foreground">Log in</span>.
            </p>
          )}
        </div>
      </main>
    </div>
  )
}

function Field({
  label,
  value,
  onChange,
  type = 'text',
  placeholder,
  required,
}: {
  label: string
  value: string
  onChange: (v: string) => void
  type?: string
  placeholder?: string
  required?: boolean
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <Label>{label}</Label>
      <Input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        required={required}
      />
    </div>
  )
}
