'use client'

import Link from 'next/link'
import { useMemo, useState } from 'react'
import { ArrowRight, Bus, Car, CheckCircle2, Footprints, LocateFixed, MapPin, Navigation, Radio, ShieldCheck } from 'lucide-react'
import { useApp } from '@/components/auth-provider'
import { MapView, type MapPin as MapPinType } from '@/components/map-view'
import { SiteHeader } from '@/components/site-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { formatKm } from '@/lib/geo'
import { fareFor, formatMwk } from '@/lib/pricing'
import { QUALITY_BADGE, routeColor } from '@/lib/route-ui'
import { findTrips } from '@/lib/search'
import { haversineKm, nearestStopIndex } from '@/lib/geo'
import { KNOWN_PLACES } from '@/lib/seed-data'
import type { LatLng } from '@/lib/types'
import { cn } from '@/lib/utils'

export default function FindPage() {
  const { routes, currentUser, requestTransport } = useApp()
  const [originIdx, setOriginIdx] = useState<string>('')
  const [destination, setDestination] = useState<(LatLng & { name: string }) | null>(null)
  const [destinationName, setDestinationName] = useState('')
  const [currentLocation, setCurrentLocation] = useState<LatLng | null>(null)
  const [locationStatus, setLocationStatus] = useState<'idle' | 'loading' | 'ready' | 'error'>('idle')
  const [submitted, setSubmitted] = useState(false)

  const origin = currentLocation ?? (originIdx !== '' ? KNOWN_PLACES[Number(originIdx)] : null)

  const useCurrentLocation = () => {
    if (!navigator.geolocation) {
      setLocationStatus('error')
      return
    }
    setLocationStatus('loading')
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setCurrentLocation({ lat: position.coords.latitude, lng: position.coords.longitude })
        setOriginIdx('')
        setSubmitted(false)
        setLocationStatus('ready')
      },
      () => setLocationStatus('error'),
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 30000 },
    )
  }

  const trips = useMemo(() => {
    if (!submitted || !origin || !destination) return []
    return findTrips(routes, origin, destination)
  }, [submitted, origin, destination, routes])

  const nearestVehicle = useMemo(() => {
    if (!origin) return null
    return routes
      .map((route) => {
        const stop = route.stops[nearestStopIndex(route.stops, origin)]
        return { route, stop, distanceKm: haversineKm(origin, stop) }
      })
      .sort((a, b) => a.distanceKm - b.distanceKm)[0] ?? null
  }, [origin, routes])

  const directDistanceKm = origin && destination ? haversineKm(origin, destination) : 0
  const directFare = nearestVehicle ? fareFor(nearestVehicle.route.quality, directDistanceKm) : 0

  const mapRoutes = trips.map((t) => ({
    id: t.route.id,
    name: t.route.name,
    color: routeColor(t.route.id),
    stops: t.route.stops,
  }))

  const pins: MapPinType[] = []
  if (origin) pins.push({ ...origin, label: currentLocation ? 'Your current location' : `From: ${'name' in origin ? origin.name : 'Pickup'}`, kind: 'origin' })
  if (destination)
    pins.push({ ...destination, label: `To: ${destination.name}`, kind: 'destination' })
  if (nearestVehicle) {
    pins.push({
      ...nearestVehicle.stop,
      label: `Available ${nearestVehicle.route.vehicleType} · ${nearestVehicle.route.vehiclePlate ?? 'plate pending'}`,
      kind: 'vehicle',
    })
  }

  const canSearch = Boolean(origin && destination && destinationName.trim())

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-col gap-1">
          <h1 className="text-2xl font-semibold">Find transport near you</h1>
          <p className="text-sm text-muted-foreground">
            Choose where you are and where you want to go. We&apos;ll find the
            nearest minibus or taxi heading that way and price the trip.
          </p>
        </div>

        <div className="mt-6 grid gap-6 lg:grid-cols-5">
          <div className="lg:col-span-2">
            <div className="rounded-xl border border-border bg-card p-5">
              <div className="flex flex-col gap-4">
                <PlaceSelect
                  label="Your location"
                  icon={<Navigation className="size-4 text-primary" />}
                  value={originIdx}
                  onChange={(v) => {
                    if (v === null) return
                    setOriginIdx(v)
                    setCurrentLocation(null)
                    setSubmitted(false)
                  }}
                />
                <Button
                  type="button"
                  variant="outline"
                  className="w-full justify-start gap-2"
                  onClick={useCurrentLocation}
                  disabled={locationStatus === 'loading'}
                >
                  <LocateFixed className="size-4 text-primary" />
                  {locationStatus === 'loading' ? 'Locating you…' : locationStatus === 'ready' ? 'Using your exact location' : 'Use my current location'}
                </Button>
                {locationStatus === 'error' && (
                  <p className="text-xs text-destructive">Location access was unavailable. Choose a pickup place instead.</p>
                )}
                <div className="flex flex-col gap-1.5">
                  <label htmlFor="destination-name" className="flex items-center gap-1.5 text-sm font-medium">
                    <MapPin className="size-4 text-emerald-400" />
                    Where are you going?
                  </label>
                  <input
                    id="destination-name"
                    value={destinationName}
                    onChange={(event) => {
                      setDestinationName(event.target.value)
                      setSubmitted(false)
                    }}
                    placeholder="Enter any destination name"
                    className="h-10 rounded-md border border-input bg-background px-3 text-sm outline-none ring-offset-background placeholder:text-muted-foreground focus-visible:ring-2 focus-visible:ring-ring"
                  />
                  <p className="text-xs text-muted-foreground">Click your destination on the map to set the exact point.</p>
                  {destination && <p className="text-xs text-emerald-300">Destination point selected: {destination.lat.toFixed(4)}, {destination.lng.toFixed(4)}</p>}
                </div>
                <Button
                  disabled={!canSearch}
                  onClick={() => setSubmitted(true)}
                  className="w-full"
                >
                  Find transport
                  <ArrowRight className="size-4" />
                </Button>
                {origin && destination && haversineKm(origin, destination) < 0.1 && (
                  <p className="text-xs text-destructive">
                    Choose a destination farther from your pickup point.
                  </p>
                )}
              </div>
            </div>

            {nearestVehicle && (
              <div className="mt-4 rounded-xl border border-primary/30 bg-primary/10 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2 text-sm font-semibold">
                      <Radio className="size-4 text-primary" />
                      Nearest available transport
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{formatKm(nearestVehicle.distanceKm)} from your pickup point</p>
                  </div>
                  <Badge className="gap-1 bg-emerald-500/15 text-emerald-300">
                    <CheckCircle2 className="size-3" /> Available
                  </Badge>
                </div>
                <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                  <div className="rounded-lg bg-background/40 p-3">
                    <p className="text-xs text-muted-foreground">Vehicle</p>
                    <p className="mt-1 font-medium capitalize">{nearestVehicle.route.vehicleType}</p>
                  </div>
                  <div className="rounded-lg bg-background/40 p-3">
                    <p className="text-xs text-muted-foreground">Number plate</p>
                    <p className="mt-1 font-medium">{nearestVehicle.route.vehiclePlate ?? 'Pending'}</p>
                  </div>
                </div>
                {destination && (
                  <div className="mt-3 flex items-center justify-between rounded-lg border border-primary/20 bg-background/40 px-3 py-2">
                    <div>
                      <p className="text-xs text-muted-foreground">Direct fare estimate</p>
                      <p className="text-xs text-muted-foreground">{formatKm(directDistanceKm)} × quality rate</p>
                    </div>
                    <p className="text-lg font-semibold text-primary">{formatMwk(directFare)}</p>
                  </div>
                )}
                <Button
                  className="mt-3 w-full"
                  onClick={() => {
                    if (!origin || !destination || !nearestVehicle) return
                    requestTransport({
                      customerName: currentUser?.name ?? 'Guest customer',
                      customerPhone: currentUser?.phone || 'Guest request',
                      pickup: origin.name ?? 'Current location',
                      destination: destination.name,
                      distanceKm: directDistanceKm,
                      fare: directFare,
                      vehicleType: nearestVehicle.route.vehicleType,
                    })
                    setSubmitted(true)
                  }}
                  disabled={!destination || !nearestVehicle}
                >
                  Request this transport
                  <ArrowRight className="size-4" />
                </Button>
              </div>
            )}

            {submitted && (
              <div className="mt-4 flex flex-col gap-3">
                <p className="text-xs text-muted-foreground">
                  {trips.length} option{trips.length === 1 ? '' : 's'} found,
                  nearest first
                </p>
                {trips.map((t) => (
                  <div
                    key={t.route.id}
                    className="rounded-xl border border-border bg-card p-4"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <Link
                        href={`/routes/${t.route.id}`}
                        className="flex items-center gap-2 font-medium hover:text-primary"
                      >
                        <span
                          className="size-2.5 rounded-full"
                          style={{ backgroundColor: routeColor(t.route.id) }}
                        />
                        {t.route.name}
                      </Link>
                      <Badge
                        variant="outline"
                        className={cn(QUALITY_BADGE[t.route.quality].className)}
                      >
                        {QUALITY_BADGE[t.route.quality].label}
                      </Badge>
                    </div>

                    <div className="mt-3 flex items-center gap-1.5 text-sm">
                      {t.route.vehicleType === 'taxi' ? (
                        <Car className="size-4 text-muted-foreground" />
                      ) : (
                        <Bus className="size-4 text-muted-foreground" />
                      )}
                      <span>
                        Board at <strong>{t.boardingStop.name}</strong> → drop at{' '}
                        <strong>{t.alightStop.name}</strong>
                      </span>
                    </div>

                    <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
                      <span className="inline-flex items-center gap-1">
                        <Footprints className="size-3.5" />
                        {formatKm(t.boardingWalkKm)} to stop
                      </span>
                      <span>{formatKm(t.travelKm)} ride</span>
                      <span>every {t.route.frequencyMins}m</span>
                    </div>

                    <div className="mt-3 flex items-center justify-between border-t border-border pt-3">
                      <span className="text-xs text-muted-foreground">Fare</span>
                      <span className="text-lg font-semibold text-primary">
                        {formatMwk(t.fare)}
                      </span>
                    </div>
                  </div>
                ))}
                {trips.length === 0 && (
                  <p className="rounded-lg border border-border bg-card p-6 text-center text-sm text-muted-foreground">
                    No transport found within walking distance of both points.
                    Try nearby locations.
                  </p>
                )}
              </div>
            )}
          </div>

          <div className="lg:col-span-3">
            <div className="overflow-hidden rounded-xl border border-border">
              <MapView
                routes={submitted ? mapRoutes : []}
                pins={pins}
                height={560}
                onMapClick={(point) => {
                  setDestination({
                    ...point,
                    name: destinationName.trim() || 'Selected destination',
                  })
                  setSubmitted(false)
                }}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  )
}

function PlaceSelect({
  label,
  icon,
  value,
  onChange,
}: {
  label: string
  icon: React.ReactNode
  value: string
  onChange: (v: string | null) => void
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="flex items-center gap-1.5 text-sm font-medium">
        {icon}
        {label}
      </span>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="w-full">
          <SelectValue placeholder="Select a place" />
        </SelectTrigger>
        <SelectContent>
          {KNOWN_PLACES.map((p, i) => (
            <SelectItem key={p.name} value={String(i)}>
              {p.name} · {p.city}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}
