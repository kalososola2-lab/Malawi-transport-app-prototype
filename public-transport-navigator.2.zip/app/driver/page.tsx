'use client'

import { useEffect, useState } from 'react'
import { CarFront, CheckCircle2, MapPin, Phone, Radio, ShieldCheck } from 'lucide-react'
import { useRouter } from 'next/navigation'
import { useApp } from '@/components/auth-provider'
import { SiteHeader } from '@/components/site-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { formatKm } from '@/lib/geo'
import { formatMwk } from '@/lib/pricing'

export default function DriverPage() {
  const router = useRouter()
  const { currentUser, requests, acceptRequest, updateDriverProfile } = useApp()
  const [plate, setPlate] = useState(currentUser?.vehiclePlate ?? '')
  const [description, setDescription] = useState(currentUser?.vehicleDescription ?? '')
  const [saved, setSaved] = useState(false)

  useEffect(() => {
    if (!currentUser) router.push('/login')
    else if (currentUser.role !== 'driver') router.push(currentUser.role === 'operator' ? '/dashboard' : '/find')
  }, [currentUser, router])

  if (!currentUser || currentUser.role !== 'driver') return null
  const pendingRequests = requests.filter((request) => request.status === 'pending')

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <p className="text-sm font-medium text-primary">Driver dispatch</p>
            <h1 className="mt-1 text-3xl font-semibold">Your next passenger is nearby</h1>
            <p className="mt-2 text-sm text-muted-foreground">See customer requests, contact details, and accept the rides you can serve.</p>
          </div>
          <Badge className="gap-1 bg-emerald-500/15 text-emerald-300"><Radio className="size-3" /> Online</Badge>
        </div>

        <div className="mt-8 grid gap-6 lg:grid-cols-[0.8fr_1.2fr]">
          <section className="rounded-xl border border-border bg-card p-6">
            <div className="flex items-center gap-2"><CarFront className="size-5 text-primary" /><h2 className="font-semibold">Vehicle profile</h2></div>
            <p className="mt-2 text-sm text-muted-foreground">Customers see these details before they confirm a ride.</p>
            <div className="mt-5 grid gap-4">
              <div className="grid gap-2"><Label htmlFor="plate">Number plate</Label><Input id="plate" value={plate} onChange={(event) => { setPlate(event.target.value); setSaved(false) }} placeholder="e.g. NA 4821" /></div>
              <div className="grid gap-2"><Label htmlFor="car-description">Car description</Label><Input id="car-description" value={description} onChange={(event) => { setDescription(event.target.value); setSaved(false) }} placeholder="e.g. white Toyota Corolla sedan" /></div>
              <Button onClick={() => { updateDriverProfile(plate, description); setSaved(true) }}><ShieldCheck className="size-4" />{saved ? 'Vehicle details saved' : 'Save vehicle details'}</Button>
            </div>
          </section>

          <section className="rounded-xl border border-border bg-card p-6">
            <div className="flex items-center justify-between gap-3"><div><h2 className="font-semibold">Incoming transport requests</h2><p className="mt-1 text-sm text-muted-foreground">Customer name and phone are visible only to drivers handling requests.</p></div><Badge variant="outline">{pendingRequests.length} waiting</Badge></div>
            <div className="mt-5 grid gap-3">
              {pendingRequests.map((request) => (
                <div key={request.id} className="rounded-lg border border-border bg-background/40 p-4">
                  <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="font-medium">{request.customerName}</p><a className="mt-1 flex items-center gap-1 text-sm text-primary" href={`tel:${request.customerPhone}`}><Phone className="size-3" />{request.customerPhone}</a></div><Badge className="bg-primary/15 text-primary">{formatMwk(request.fare)}</Badge></div>
                  <div className="mt-4 grid gap-2 text-sm text-muted-foreground sm:grid-cols-2"><p className="flex items-center gap-2"><MapPin className="size-4 text-primary" />{request.pickup} to {request.destination}</p><p>{formatKm(request.distanceKm)} · {request.vehicleType}</p></div>
                  <Button className="mt-4 w-full" onClick={() => acceptRequest(request.id)}><CheckCircle2 className="size-4" />Accept passenger</Button>
                </div>
              ))}
              {pendingRequests.length === 0 && <div className="rounded-lg border border-dashed border-border p-8 text-center text-sm text-muted-foreground">No new requests yet. Stay online to receive the next customer.</div>}
            </div>
          </section>
        </div>
      </main>
    </div>
  )
}
