'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Plus, Route as RouteIcon, Trash2 } from 'lucide-react'
import { useApp } from '@/components/auth-provider'
import { RouteForm } from '@/components/route-form'
import { SiteHeader } from '@/components/site-header'
import { Badge } from '@/components/ui/badge'
import { Button } from '@/components/ui/button'
import { formatKm, routeLengthKm } from '@/lib/geo'
import { fareFor, formatMwk } from '@/lib/pricing'
import { QUALITY_BADGE, routeColor } from '@/lib/route-ui'
import { cn } from '@/lib/utils'

export default function DashboardPage() {
  const router = useRouter()
  const { currentUser, routes, deleteRoute } = useApp()
  const [showForm, setShowForm] = useState(false)

  useEffect(() => {
    if (!currentUser) router.push('/login')
    else if (currentUser.role !== 'operator') router.push(currentUser.role === 'driver' ? '/driver' : '/find')
  }, [currentUser, router])

  if (!currentUser) return null

  const myRoutes = routes.filter((r) => r.operatorId === currentUser.id)

  return (
    <div className="min-h-screen">
      <SiteHeader />
      <main className="mx-auto max-w-6xl px-4 py-8">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <h1 className="text-2xl font-semibold">{currentUser.name}</h1>
            <p className="text-sm text-muted-foreground">
              Manage the routes riders can find and book.
            </p>
          </div>
          <Button onClick={() => setShowForm((v) => !v)}>
            <Plus className="size-4" />
            {showForm ? 'Close' : 'Add route'}
          </Button>
        </div>

        {showForm && (
          <div className="mt-6">
            <RouteForm onDone={() => setShowForm(false)} />
          </div>
        )}

        <div className="mt-8 grid gap-6 md:grid-cols-3">
          <Metric label="Published routes" value={String(myRoutes.length)} />
          <Metric
            label="Total network length"
            value={formatKm(
              myRoutes.reduce((sum, r) => sum + routeLengthKm(r.stops), 0),
            )}
          />
          <Metric
            label="Fleet size"
            value={String(
              myRoutes.reduce((sum, r) => sum + r.fleetSize, 0),
            )}
          />
        </div>

        <h2 className="mt-10 text-lg font-semibold">Your routes</h2>
        <div className="mt-4 flex flex-col gap-3">
          {myRoutes.map((route) => {
            const length = routeLengthKm(route.stops)
            return (
              <div
                key={route.id}
                className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-border bg-card p-4"
              >
                <div className="min-w-0">
                  <Link
                    href={`/routes/${route.id}`}
                    className="flex items-center gap-2 font-medium hover:text-primary"
                  >
                    <span
                      className="size-2.5 rounded-full"
                      style={{ backgroundColor: routeColor(route.id) }}
                    />
                    <span className="truncate">{route.name}</span>
                  </Link>
                  <div className="mt-1 flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
                    <span>{route.city}</span>
                    <span>{route.stops.length} stops</span>
                    <span>{formatKm(length)}</span>
                    <span>{formatMwk(fareFor(route.quality, length))} full fare</span>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge
                    variant="outline"
                    className={cn(QUALITY_BADGE[route.quality].className)}
                  >
                    {QUALITY_BADGE[route.quality].label}
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => deleteRoute(route.id)}
                    aria-label={`Delete ${route.name}`}
                  >
                    <Trash2 className="size-4 text-destructive" />
                  </Button>
                </div>
              </div>
            )
          })}

          {myRoutes.length === 0 && (
            <div className="flex flex-col items-center gap-3 rounded-xl border border-dashed border-border bg-card p-10 text-center">
              <RouteIcon className="size-8 text-muted-foreground" />
              <p className="text-sm text-muted-foreground">
                You haven&apos;t published any routes yet.
              </p>
              <Button onClick={() => setShowForm(true)}>
                <Plus className="size-4" />
                Add your first route
              </Button>
            </div>
          )}
        </div>
      </main>
    </div>
  )
}

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-border bg-card p-5">
      <p className="text-sm text-muted-foreground">{label}</p>
      <p className="mt-1 text-2xl font-semibold text-primary">{value}</p>
    </div>
  )
}
